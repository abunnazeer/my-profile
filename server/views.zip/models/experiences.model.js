const experiences = [
  {
    id: '1',
    expDate: 'Jan, 2020 to Present',
    expTitle: 'Web Developer-Team Lead',
    expCompany: 'Inception Technologies',
  },

  {
    id: '2',
    expDate: 'July 2020',
    expTitle: 'Core Founder ',
    expCompany: 'Arewa Stylists Studio',
  },
  {
    id: '3',
    expDate: 'Jan, 2022',
    expTitle: 'Core Founder ',
    expCompany: 'VS cloud technologies',
  },
  {
    id: '4',
    expDate: 'Jan, 2020 to Present',
    expTitle: 'Front End Developer',
    expCompany: 'Cerebro System limited',
  },

  {
    id: '5',
    expDate: 'Mar 2018 to Oct. 2022',
    expTitle: 'Junior Flutter Developer',
    expCompany: 'Mobile Robotic Technology ltd',
  },
  {
    id: '6',
    expDate: 'Jul 2014 to Jan. 2016',
    expTitle: 'Front End Developer',
    expCompany: 'Dwil Computers',
  },
];
module.exports = experiences;
