const clients = [
  {
    id: '1',
    imagePath: 'assets/img/clients/walwanne-logo.png',
  },
  {
    id: '2',
    imagePath: 'assets/img/clients/kanem.jpg',
  },
  {
    id: '3',
    imagePath: 'assets/img/clients/Inception-logo.png',
  },
  {
    id: '4',
    imagePath: 'assets/img/clients/vscloud.png',
  },
  {
    id: '5',
    imagePath: 'assets/img/clients/multiaid.png',
  },
  {
    id: '6',
    imagePath: 'assets/img/clients/ruwasalogo.png',
  },
];

module.exports = clients;
