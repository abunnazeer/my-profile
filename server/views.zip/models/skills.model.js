const skills = [
  {
    id: '1',
    icon: 'assets/icons/js.png',
    skill: 'Javascript',
  },
  {
    id: '2',
    icon: 'assets/icons/atom.png',
    skill: 'React Js',
  },
  {
    id: '3',
    icon: 'assets/icons/bootstrap.png',
    skill: 'Bootstrap',
  },
  {
    id: '4',
    icon: 'assets/icons/css.png',
    skill: 'CSS 3',
  },
  {
    id: '5',
    icon: 'assets/icons/html-5.png',
    skill: 'HTML 5',
  },
  {
    id: '6',
    icon: 'assets/icons/jquery.png',
    skill: 'JQuery',
  },
  {
    id: '7',
    icon: 'assets/icons/nodejs.png',
    skill: 'Node Js',
  },
  {
    id: '8',
    icon: 'assets/icons/figma.png',
    skill: 'Figma',
  },
  {
    id: '9',
    icon: 'assets/icons/flutter.png',
    skill: 'Flutter',
  },
];

module.exports = skills;
