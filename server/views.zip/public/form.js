document.getElementById('submit').addEventListener('click', e => {
  e.preventDefault();
  console.log('you click me');
});
